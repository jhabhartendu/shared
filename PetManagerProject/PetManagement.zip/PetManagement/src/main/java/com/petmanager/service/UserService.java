package com.petmanager.service;

import java.util.ArrayList;
import java.util.List;

import com.petmanager.provider.UserDataProvider;
import com.petmanager.vo.Pet;
import com.petmanager.vo.User;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;  
@Path("/UserService") 

public class UserService {  

   @GET 
   @Path("/users") 
   @Produces(MediaType.APPLICATION_JSON) 
   public List<User> getUsers(@HeaderParam("UserId") String callerId, 
		   @QueryParam("latitude") String lat, @QueryParam("longitude") String lgt, 
		   @QueryParam("radious") String rad){ 
	  
	   try {
		   //In the absence of auth token, lets assume user id directly is available to us.
	   
		   if( (callerId == null || callerId.trim().length() < 1) ||
				   (lat == null || lat.trim().length() < 1) ||
				   (lgt == null || lgt.trim().length() < 1) ||
				   (rad == null || rad.trim().length() < 1) 
				   ){
			   //TODO: proper error handling needed. For now return null
			   throw new Exception("All parameters not available or enough");
		   }
		   
		   double latitude = Double.parseDouble(lat);
		   double longitude = Double.parseDouble(lgt);
		   double radious = Double.parseDouble(rad);
		   
		   //Check if the current user is having premium access
		   UserDataProvider userDataProvider = UserDataProvider.getInstance();
		   if(userDataProvider.isPremiumUser(callerId)) {
			   
			   //Use latitude, longitude and radious to locate users within that limit.
			   return userDataProvider.getUsers(latitude, longitude, radious);
			   
		   } else {
			   throw new Exception("Caller is not a premium user.");
		   }
   
	   } catch (Exception e) {
		   System.out.println("Exception : " + e.getMessage());
		   e.printStackTrace();
		   //TODO: return proper error code and message. for now lets return null.
		   return null;
	   }
   }  

   // registerUser : For now lets assume he will opt in for premium service at the time of registration it self.
   @POST
   @Path("/users") 
   @Produces(MediaType.APPLICATION_JSON) 
   @Consumes(MediaType.APPLICATION_JSON)
   public User createUser(User user){ 
	   
	   //Can any one call this or only Admin kind of user?
	   //For now allow any one to call this.
	   
	   if( user == null ){
		   //TODO: proper error handling needed. For now return null
		   return null;
	   }	   
	   
	   UserDataProvider userDataProvider = UserDataProvider.getInstance();
	   userDataProvider.createUser(user);
	   
	   System.out.println("User : " + user);

	   return user;
   }
   
   // Manage Pets for users
   
   @POST
   @Path("/users/{id}/pets") 
   @Produces(MediaType.APPLICATION_JSON) 
   @Consumes(MediaType.APPLICATION_JSON)
   public Pet addPet(@HeaderParam("UserId") String callerId, 
		   @PathParam("id") String ownerId, Pet pet){ 
	   
	   if( (callerId == null || callerId.trim().length() < 1) ||
			   (ownerId == null || ownerId.trim().length() < 1) || pet == null ){
		   //TODO: proper error handling needed. For now return null
		   return null;
	   }
	   
	   //verify callerId and userId matches and user exists in the system
	   //If exists then add Pet.
	   if(callerId.trim().equalsIgnoreCase(ownerId.trim())) {
		   UserDataProvider userDataProvider = UserDataProvider.getInstance();
		   User owner = userDataProvider.getUser(ownerId);
		   if(owner != null) {
			   List<Pet> petList =  owner.getPet();
			   if(petList!= null) {
				   petList.add(pet);
			   }
			   else {
				   petList = new ArrayList<Pet>();
				   petList.add(pet);
				   owner.setPet(petList);
			   }
			   System.out.println("Pet : " + pet);
			   return pet;
		   } 
	   } 

	   return null;
   }
   
   //TODO: Get, Put for Pets.
   
   
   // login : Perform login, return auth token. let client manage it.
   		// For now skip this. Assume client will pass the user id directly in the header.
   		// we can use it to validate the user and if he has opted for premium service.
   
   // logout : logout user.
   
   // refresh :  refresh token.

}