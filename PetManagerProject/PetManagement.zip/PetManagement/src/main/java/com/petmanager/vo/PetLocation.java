package com.petmanager.vo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PetLocation {

	private String petId;
	private float latitude;
    private float longitude;
    private String towerId;
    private Date time;
    
    public PetLocation() {	
    }
    
	public PetLocation(String petId, float latitude, float longitude, String towerId, String time) {
		super();
		this.petId = petId;
		this.latitude = latitude;
		this.longitude = longitude;
		this.towerId = towerId;
		try {
			this.time = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			this.time = new Date();
		}
	}
	
	public String getPetId() {
		return petId;
	}
	public void setPetId(String petId) {
		this.petId = petId;
	}
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public float getLongitude() {
		return longitude;
	}
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}
	public String getTowerId() {
		return towerId;
	}
	public void setTowerId(String towerId) {
		this.towerId = towerId;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(String time) {
		try {
			this.time = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			this.time = new Date();
		}
	}

	@Override
	public String toString() {
		return "PetLogEntry [petId=" + petId + ", latitude=" + latitude + ", longitude=" + longitude + ", towerId="
				+ towerId + ", time=" + time + "]";
	}
	
}
