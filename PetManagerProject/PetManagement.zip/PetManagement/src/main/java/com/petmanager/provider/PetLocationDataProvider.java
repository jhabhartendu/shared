package com.petmanager.provider;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.petmanager.vo.PetLocation;

public class PetLocationDataProvider {

	//Can be fedarated to save/serve from any DB.
	//For now lets keep it in memory.
	
	//make this Singleton to hold the data across request.
	private static PetLocationDataProvider singleInstance = new PetLocationDataProvider();
	
	private	List<PetLocation> petLocation =  new ArrayList<PetLocation>();
	
	private PetLocationDataProvider() {
		//TODO: Initialize with some sample data
	}
	
	public static PetLocationDataProvider getInstance() {
		return singleInstance;
	}
	
	//Save Pet location Data
	public void saveLocation(PetLocation location) {
		petLocation.add(location);
	}
	
	//Get Pet Location Data
	public List<PetLocation> getLocation(String petId, Date startDate, Date endDate) {
		return petLocation.stream()
				.filter(l -> (l.getTime().compareTo(startDate) > 0) && (l.getTime().compareTo(endDate) < 0))
				.collect(Collectors.toList());
	}
}
