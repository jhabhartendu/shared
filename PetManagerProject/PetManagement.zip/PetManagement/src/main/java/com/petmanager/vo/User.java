package com.petmanager.vo;
import java.util.List;

public class User {

    private String id; 
    private String name; 
    private String address;
    private String zip;
    private double latitude;
    private double longitude;
   
    private List<Pet> pet;
   
    private boolean isPremiumUser;

    public User() {
      // default;
    };
    
	public User(String id, String name, String address, String zip, double latitude, double longitude, List<Pet> pet,
			boolean isPremiumUser) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.zip = zip;
		this.latitude = latitude;
		this.longitude = longitude;
		this.pet = pet;
		this.isPremiumUser = isPremiumUser;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public List<Pet> getPet() {
		return pet;
	}

	public void setPet(List<Pet> pet) {
		this.pet = pet;
	}

	public boolean isPremiumUser() {
		return isPremiumUser;
	}

	public void setPremiumUser(boolean isPremiumUser) {
		this.isPremiumUser = isPremiumUser;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + ", zip=" + zip + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", pet=" + pet + ", isPremiumUser=" + isPremiumUser + "]";
	}   
	
}
