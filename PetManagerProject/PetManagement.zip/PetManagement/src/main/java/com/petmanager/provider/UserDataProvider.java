package com.petmanager.provider;

import java.util.ArrayList;
import java.util.List;

import com.petmanager.vo.User;

public class UserDataProvider {

	//can be fedrated to any db.
	//for now lets keep in memory

	//make this Singleton to hold the data across request.
	private static UserDataProvider singleInstance = new UserDataProvider();
	
	private List<User> users = new ArrayList<User>();
	
	private UserDataProvider() {
		//TODO: initialize with some sample data.
		User user1 = new User("1", "User1", "Address 1", "500050", 17.3850, 78.4867, null, false);
		User user2 = new User("2", "User2", "Address 2", "500051", 17.3851, 78.4868, null, true);
		
		users.add(user1);
		users.add(user2);
	}
	
	public static UserDataProvider getInstance() {
		return singleInstance;
	}
	
	public void createUser(User user) {
		users.add(user);
	}
	
	public User getUser(String userId) {
		return users.stream().filter(u->(userId.equalsIgnoreCase(u.getId()))).findFirst().orElse(null);
	}
	
	public boolean isPremiumUser(String userId) {
		return users.stream().anyMatch(u->(userId.equalsIgnoreCase(u.getId())) && (u.isPremiumUser()));
	}
	
	public List<User> getUsers(double latitude, double longitude, double radious){
		// TODO:Search by location can be done using following
		
		// Ex: Using spatial queries in Oracle DB:
		//	https://asktom.oracle.com/pls/apex/f?p=100:11:::::P11_QUESTION_ID:9539156000346599825

		//Ex:	Use 3rd party search service like:
		//	https://www.algolia.com/doc/guides/managing-results/refine-results/geolocation/

		//Ex:	Google Place Search
		//	https://developers.google.com/maps/documentation/places/web-service/search

		//For now return the entire list
		
		return users;
	}
	
}
