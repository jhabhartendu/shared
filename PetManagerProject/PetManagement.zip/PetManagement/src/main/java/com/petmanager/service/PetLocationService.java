package com.petmanager.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.petmanager.provider.PetLocationDataProvider;
import com.petmanager.provider.UserDataProvider;
import com.petmanager.vo.PetLocation;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/PetService") 

public class PetLocationService {

   
	   @POST
	   @Path("/petLocations") 
	   @Produces(MediaType.APPLICATION_JSON) 
	   @Consumes(MediaType.APPLICATION_JSON)
	   public PetLocation captureLocation(PetLocation petLocation){ 
		   // Take care of transformation 
		   // exception handling
		   // logging etc.
		   PetLocationDataProvider petLocationProvider = PetLocationDataProvider.getInstance();
		   petLocationProvider.saveLocation(petLocation);
		   
		   System.out.println("Pet Location : " + petLocation);
		   return petLocation;
	   }
	   
	   @GET 
	   @Path("/petLocations") 
	   @Produces(MediaType.APPLICATION_JSON) 
	   public List<PetLocation> getLocations(@HeaderParam("UserId") String callerId, @QueryParam("petId") String petId,
			   @QueryParam("startTime") String start, @QueryParam("endTime") String end){ 
		   try {
			   //In the absence of auth token, lets assume user id directly is available to us.
			   
			   if( (callerId == null || callerId.trim().length() < 1) ||
					   (petId == null || petId.trim().length() < 1) ||
					   (start == null || start.trim().length() < 1) ||
					   (end == null || end.trim().length() < 1) 
					   ){
				   System.out.println("Caller: " + callerId + " PetId:" + petId + " start: " + start + " end:" + end);
				   throw new Exception("All parameters not available or enough");
			   }
			   
			   Date startTime = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(start);  
			   Date endTime = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(end);  
			   
			   //Check if the current user is having premium access
			   UserDataProvider userDataProvider = UserDataProvider.getInstance();
			   if(userDataProvider.isPremiumUser(callerId)) {
				   // Check for 30 days limit
				   if( ( (new Date().getTime() - startTime.getTime()) > new Long("2592000000").longValue() ) ||
					         endTime.compareTo(startTime) <= 0 ||  new Date().compareTo(endTime) < 0 ) {
					   throw new Exception("Dates are out of range");
				   }
			   } else {
				   // check for 1 day limit
				   if( ( new Date().getTime() - startTime.getTime() >  new Long("86400000").longValue() ) ||
					         endTime.compareTo(startTime) <= 0 ||  new Date().compareTo(endTime) < 0 ) {
						   throw new Exception("Dates are out of range");
					   }
			   }

			   //Get PetLocation data provider and do the query.
			   PetLocationDataProvider petLocationProvider = PetLocationDataProvider.getInstance();
			   return petLocationProvider.getLocation(petId, startTime, endTime);

		   } catch(Exception e) {
			   System.out.println("Exception : " + e.getMessage());
			   e.printStackTrace();
			   //TODO: return proper error code and message. for now lets return null.
			   return null;
		   }
	   } 
	   
}
